<?php


// 1. The Catalog Data
$catalog = [
    'HW-101' => ['name' => 'Mechanical Keyboard RGB', 'price' => 89.99],
    'HW-103' => ['name' => '27-inch 4K IPS Monitor', 'price' => 329.00],
    'HW-107' => ['name' => '34-inch Ultrawide Monitor', 'price' => 499.99],
    'HW-109' => ['name' => 'Braided HDMI 2.1 Cable', 'price' => 14.99]
];

// 2. Setup default variables (so they exist on first load)
$company_name = '';
$selected_products = [];
$bundle_qty = 1;
$promo_code = '';
$errors = [];

// 3. Handle the POST submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Grab and trim inputs
    $company_name = trim($_POST['company_name'] ?? '');
    $selected_products = $_POST['product_ids'] ?? [];
    $bundle_qty = $_POST['bundle_qty'] ?? '';
    $promo_code = strtoupper(trim($_POST['promo_code'] ?? ''));

    // --- VALIDATION ---
    // Company name
    if (strlen($company_name) < 2 || strlen($company_name) > 60) {
        $errors[] = "Company name must be between 2 and 60 characters.";
    }

    // Products (must be an array, at least 1 item, and all keys must exist in catalog)
    if (!is_array($selected_products) || count($selected_products) === 0) {
        $errors[] = "Please select at least one product.";
    } else {
        foreach ($selected_products as $sku) {
            if (!array_key_exists($sku, $catalog)) {
                $errors[] = "Invalid product selected.";
                break; // Stop checking if one is fake
            }
        }
    }

    // Quantity (1 to 20 using filter_var)
    $valid_qty = filter_var($bundle_qty, FILTER_VALIDATE_INT, [
        'options' => ['min_range' => 1, 'max_range' => 20]
    ]);
    if ($valid_qty === false) {
        $errors[] = "Quantity must be a whole number between 1 and 20.";
    }

    // Promo code using match
    $discountRate = match ($promo_code) {
        ''       => 0.0,    // No code entered is fine (0% off)
        'SAVE10' => 0.10,   // 10% off
        'VIP20'  => 0.20,   // 20% off
        default  => -1.0    // Invalid code
    };
    if ($discountRate === -1.0) {
        $errors[] = "Invalid promo code.";
    }

    // --- REDIRECT AFTER SUCCESS ---
    if (empty($errors)) {
        // Calculate totals
        $subtotal = 0;
        foreach ($selected_products as $sku) {
            $subtotal += $catalog[$sku]['price'] * $valid_qty;
        }
        $discountAmount = $subtotal * $discountRate;
        $finalTotal = $subtotal - $discountAmount;

        // Build the query string
        $queryData = [
            'company' => $company_name,
            'items'   => implode(', ', $selected_products), // Turn array into a string
            'qty'     => $valid_qty,
            'total'   => number_format($finalTotal, 2, '.', '')
        ];
        $queryString = http_build_query($queryData);

        // Redirect and EXIT
        header('Location: q21_quote_success.php?' . $queryString);
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>B2B Quote Builder</title></head>
<body>
    <h2>Hardware B2B Quote Builder</h2>

    <?php if (!empty($errors)): ?>
        <div style="color:red; border: 1px solid red; padding: 10px;">
            <ul>
                <?php foreach ($errors as $err): ?>
                    <li><?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form uses POST and action="" to submit to itself -->
    <form method="POST" action="">
        <label>Company Name:</label><br>
        <input type="text" name="company_name" value="<?= htmlspecialchars($company_name, ENT_QUOTES, 'UTF-8') ?>"><br><br>

        <label>Select Products:</label><br>
        <?php foreach ($catalog as $sku => $item): ?>
            <label>
                <!-- Sticky Checkboxes -->
                <input type="checkbox" name="product_ids[]" value="<?= $sku ?>" 
                    <?= in_array($sku, $selected_products) ? 'checked' : '' ?>>
                <?= htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8') ?> ($<?= $item['price'] ?>)
            </label><br>
        <?php endforeach; ?>
        <br>

        <label>Bundle Quantity (1-20):</label><br>
        <input type="number" name="bundle_qty" value="<?= htmlspecialchars((string)$bundle_qty, ENT_QUOTES, 'UTF-8') ?>"><br><br>

        <label>Promo Code (SAVE10 or VIP20):</label><br>
        <input type="text" name="promo_code" value="<?= htmlspecialchars($promo_code, ENT_QUOTES, 'UTF-8') ?>"><br><br>

        <button type="submit">Generate Quote</button>
    </form>
</body>
</html>
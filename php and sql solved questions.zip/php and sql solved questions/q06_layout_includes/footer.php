<hr>
<footer>
    <p>Need help? Contact
        <a href= "mailto:<?= htmlspecialchars(SUPPORT_EMAIL, ENT_QUOTES, 'UTF-8') ?>">
            <?= htmlspecialchars(SUPPORT_EMAIL, ENT_QUOTES, 'UTF-8') ?>
</a>
</p>

<p>Portal version: <?= htmlspecialchars(getPortalVersion(), ENT_QUOTES, 'UTF-8') ?> </p>
</footer>
</body>
</html>

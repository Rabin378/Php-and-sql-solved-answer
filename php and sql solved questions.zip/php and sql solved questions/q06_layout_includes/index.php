<?php
require_once __DIR__ .'/config.php';

include __DIR__ .'/header.php';
?>

<main>
<h2>Welcome</h2>
<p> This page is assembled from shared header ,footer, and config files.</p>
</main>

<?php 
include __DIR__.'/footer.php';
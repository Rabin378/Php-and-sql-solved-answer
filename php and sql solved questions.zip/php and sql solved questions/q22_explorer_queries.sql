USE webprog2_midterm;

-- Query 1: Filtered Aggregates (Price <= 100)
SELECT 
    COUNT(*) AS total_matches, 
    AVG(unit_price) AS avg_price, 
    MIN(unit_price) AS min_price, 
    MAX(unit_price) AS max_price 
FROM products 
WHERE unit_price <= 100.00;

-- Query 2: Filtered Pagination (Price <= 100)
SELECT 
    sku, 
    product_name, 
    category, 
    unit_price, 
    stock_qty 
FROM products 
WHERE unit_price <= 100.00 
ORDER BY unit_price ASC 
LIMIT 3 OFFSET 0;
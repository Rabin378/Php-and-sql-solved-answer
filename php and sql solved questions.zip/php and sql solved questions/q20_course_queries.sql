USE webprog2_midterm;

-- Query 1: CS Courses with Estimated Tuition
SELECT 
    course_code, 
    title, 
    credits, 
    lab_fee, 
    (credits * 120 + lab_fee) AS est_tuition 
FROM courses 
WHERE department = 'CS' 
ORDER BY lab_fee ASC;

-- Query 2: Online Design Courses
SELECT 
    course_code, 
    title, 
    department, 
    max_seats 
FROM courses 
WHERE is_online = 1 AND title LIKE '%Design%' 
ORDER BY course_code ASC;
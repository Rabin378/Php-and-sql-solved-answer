<?php
declare(strict_types = 1);

function buildshippingLabel(
    string $recipient,
    float $weightKg,
    bool $fragile= false, 
    bool $express = false,
    ?string $deliveryNote = null
): string {
    $fragileText = $fragile ? "Yes" : "No";
    $expressText = $express ? "Yes" : "NO";
    $noteText = $deliveryNote ??"None";

    $label = "Recipient: " .$recipient;
    $label .= "| Weight: " .$weightKg. " kg";
    $label .= "| Fragile: " . $fragileText;
    $label .= "| Express: " . $expressText;
    $label .= " | Note: " . $noteText;

    return $label;

}
?>
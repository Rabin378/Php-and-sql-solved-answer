-- Q17: Pages of 4 products, plus a "top 3 cheapest" widget
-- LIMIT = how many rows to return
-- OFFSET = how many rows to skip first
-- Always use ORDER BY so the rows come back in a predictable order.
USE webprog2_midterm;

-- Query A: Page 1 (rows 1 to 4): skip 0, take 4
SELECT product_id, sku, product_name, unit_price
FROM products
ORDER BY product_id ASC
LIMIT 4 OFFSET 0;

-- Query B: Page 2 (rows 5 to 8): skip 4, take 4
SELECT product_id, sku, product_name, unit_price
FROM products
ORDER BY product_id ASC
LIMIT 4 OFFSET 4;

-- Query C: Page 3 (rows 9 to 12): skip 8, take 4
SELECT product_id, sku, product_name, unit_price
FROM products
ORDER BY product_id ASC
LIMIT 4 OFFSET 8;

-- Query D: The 3 cheapest accessories
SELECT sku, product_name, unit_price
FROM products
WHERE category = 'Accessories'
ORDER BY unit_price ASC
LIMIT 3;

<?php
declare(strict_types = 1);

require_once __DIR__.  '/q08_functions.php';

$label1 = buildShippingLabel(
    recipient: 'Kim Tae-hyung',
    weightKg: 4.5,
    express: true,
    deliveryNote: 'Leave at front desk'
);

$label2 = buildShippingLabel(
    recipient : 'Choi Ji-woo',
    weightKg: 1.25,
    fragile: true

);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Shipping Lable Generator</h1>
<?php
echo "<h2>Shipping Label 1</h2>";
echo "<p>".htmlspecialchars($label1 , ENT_QUOTES, 'UTF-8'). "</p>";

echo "<h2>Shipping label 2 </h2>";
echo "<p>".htmlspecialchars($label2, ENT_QUOTES, 'UTF-8'). "</p>";
?>
</body>
</html>
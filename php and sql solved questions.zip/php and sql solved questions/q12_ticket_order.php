<?php
// ---------- Constants ----------
$ticketPrice = 45.00;

// ---------- Variables ----------
$email        = '';
$rawTickets   = '';
$rawDonation  = '';
$validTickets = false;
$donation     = 0.0;
$ticketCost   = 0.0;
$total        = 0.0;
$errors       = [];
$isSubmitted  = false;

// ---------- Handle form submission ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isSubmitted = true;

    $email       = trim($_POST['email'] ?? '');
    $rawTickets  = trim($_POST['tickets'] ?? '');
    $rawDonation = trim($_POST['donation'] ?? '');

    // Validate email
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        $errors[] = 'Please enter a valid email address.';
    }

    // Validate number of tickets (integer from 1 to 5)
    $validTickets = filter_var(
        $rawTickets,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1, 'max_range' => 5]]
    );

    if ($validTickets === false) {
        $errors[] = 'Number of tickets must be an integer from 1 to 5.';
    }

    // Validate donation (optional, from 0 to 500)
    if ($rawDonation === '') {
        $donation = 0.0;
    } else {
        $donation = filter_var($rawDonation, FILTER_VALIDATE_FLOAT);
    }

    if ($donation === false || $donation < 0 || $donation > 500) {
        $errors[] = 'Donation must be a number from 0.00 to 500.00.';
    }

    // Calculate totals only when the order is valid
    if (empty($errors)) {
        $ticketCost = $validTickets * $ticketPrice;
        $total      = $ticketCost + $donation;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 650px;
            margin: 40px auto;
            padding: 20px;
            line-height: 1.6;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px 18px;
            cursor: pointer;
        }
        .error {
            color: #b00020;
            background: #fff0f0;
            padding: 12px 30px;
            margin-bottom: 20px;
        }
        .success {
            border: 1px solid #80b880;
            background: #f3fff3;
            padding: 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <h1>Conference Ticket Reservation</h1>
    <p>Each ticket costs $<?php echo number_format($ticketPrice, 2); ?>.</p>

    <?php if (!empty($errors)): ?>
        <div class="error">
            <h2>Please correct these errors:</h2>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($isSubmitted && empty($errors)): ?>

        <div class="success">
            <h2>Order Submitted Successfully!</h2>

            <p>
                <strong>Email:</strong>
                <?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>
            </p>

            <p>
                <strong>Number of tickets:</strong>
                <?php echo $validTickets; ?>
            </p>

            <p>
                <strong>Ticket cost:</strong>
                $<?php echo number_format($ticketCost, 2); ?>
            </p>

            <p>
                <strong>Donation:</strong>
                $<?php echo number_format($donation, 2); ?>
            </p>

            <h3>Total Due: $<?php echo number_format($total, 2); ?></h3>
        </div>

    <?php else: ?>

        <form method="post" action="">

            <label for="email">Email Address</label>
            <input
                type="text"
                id="email"
                name="email"
                value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                required
            >

            <label for="tickets">Number of Tickets (1 - 5)</label>
            <input
                type="number"
                id="tickets"
                name="tickets"
                min="1"
                max="5"
                step="1"
                value="<?php echo htmlspecialchars($rawTickets, ENT_QUOTES, 'UTF-8'); ?>"
                required
            >

            <label for="donation">Optional Donation ($0.00 - $500.00)</label>
            <input
                type="number"
                id="donation"
                name="donation"
                min="0"
                max="500"
                step="any"
                value="<?php echo htmlspecialchars($rawDonation, ENT_QUOTES, 'UTF-8'); ?>"
                placeholder="Leave blank for $0.00"
            >

            <button type="submit">Place Order</button>

        </form>

    <?php endif; ?>

</body>
</html>
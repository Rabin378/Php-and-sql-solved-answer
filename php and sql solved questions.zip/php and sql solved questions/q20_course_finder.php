<?php
declare(strict_types=1);
require_once __DIR__ . '/q20_functions.php';

// 1. The Data (from the SQL INSERT statements in the PDF)
$courses = [
    ['code' => 'CS101', 'title' => 'Introduction to Programming', 'dept' => 'CS', 'credits' => 4, 'fee' => 50.00, 'online' => 0],
    ['code' => 'CS202', 'title' => 'Web Programming 2 (PHP & SQL)', 'dept' => 'CS', 'credits' => 4, 'fee' => 75.00, 'online' => 0],
    ['code' => 'CS215', 'title' => 'Database Management Systems', 'dept' => 'CS', 'credits' => 3, 'fee' => 60.00, 'online' => 1],
    ['code' => 'IT110', 'title' => 'Networking Fundamentals', 'dept' => 'IT', 'credits' => 3, 'fee' => 85.00, 'online' => 0],
    ['code' => 'IT240', 'title' => 'Cloud Infrastructure Basics', 'dept' => 'IT', 'credits' => 3, 'fee' => 40.00, 'online' => 1],
    ['code' => 'DS105', 'title' => 'UI/UX Design Principles', 'dept' => 'Design', 'credits' => 3, 'fee' => 30.00, 'online' => 1],
    ['code' => 'DS220', 'title' => 'Responsive Frontend Systems', 'dept' => 'Design', 'credits' => 4, 'fee' => 55.00, 'online' => 0],
    ['code' => 'CS301', 'title' => 'Software Engineering Lab', 'dept' => 'CS', 'credits' => 4, 'fee' => 90.00, 'online' => 0]
];

// 2. Validate GET inputs
$allowedDepts = ['ALL', 'CS', 'IT', 'Design'];
$dept = $_GET['dept'] ?? 'ALL';
if (!in_array($dept, $allowedDepts, true)) {
    $dept = 'ALL'; 
}

$keyword = trim($_GET['keyword'] ?? '');
$errors = [];
if (strlen($keyword) > 40) {
    $errors[] = "Keyword must be 40 characters or less.";
    $keyword = ""; // Reset keyword on error
}

$onlyOnline = isset($_GET['only_online']);

// 3. Filter the array using foreach
$filteredCourses = [];
foreach ($courses as $course) {
    // Check 1: Department match
    $deptMatch = ($dept === 'ALL' || $course['dept'] === $dept);
    
    // Check 2: Keyword match (case-insensitive)
    // stripos returns false if not found, or the index position if found.
    $keywordMatch = ($keyword === '' || stripos($course['title'], $keyword) !== false);
    
    // Check 3: Online only match
    $onlineMatch = (!$onlyOnline || $course['online'] === 1);

    if ($deptMatch && $keywordMatch && $onlineMatch) {
        $filteredCourses[] = $course;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Course Finder</title></head>
<body>
    <h2>University Course Finder</h2>
    
    <!-- Sticky GET Form -->
    <form method="GET">
        <label>Department:</label>
        <select name="dept">
            <option value="ALL" <?= $dept === 'ALL' ? 'selected' : '' ?>>ALL</option>
            <option value="CS" <?= $dept === 'CS' ? 'selected' : '' ?>>CS</option>
            <option value="IT" <?= $dept === 'IT' ? 'selected' : '' ?>>IT</option>
            <option value="Design" <?= $dept === 'Design' ? 'selected' : '' ?>>Design</option>
        </select>

        <label>Keyword:</label>
        <input type="text" name="keyword" value="<?= htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') ?>">

        <label>
            <input type="checkbox" name="only_online" value="1" <?= $onlyOnline ? 'checked' : '' ?>> 
            Online Only
        </label>

        <button type="submit">Search</button>
    </form>

    <!-- Display Errors if any -->
    <?php if (!empty($errors)): ?>
        <div style="color:red;">
            <?php foreach ($errors as $e): ?><p><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8') ?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Results Table -->
    <table border="1" cellpadding="5">
        <tr>
            <th>Code</th>
            <th>Title</th>
            <th>Department</th>
            <th>Credits</th>
            <th>Fee</th>
            <th>Format</th>
            <th>Est. Tuition</th>
        </tr>
        <?php foreach ($filteredCourses as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['code'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($c['title'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars(getDepartmentLabel($c['dept']), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)$c['credits'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>$<?= number_format($c['fee'], 2) ?></td>
                <td><?= $c['online'] ? 'Online' : 'In-Person' ?></td>
                <td>$<?= number_format(calculateCourseCost($c['credits'], $c['fee']), 2) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
-- Q16: Read-only reports from the products table
USE webprog2_midterm;

-- Query A: Featured items priced between 50.00 and 350.00, most expensive first
SELECT sku, product_name, category, unit_price
FROM products
WHERE is_featured = 1
  AND unit_price BETWEEN 50.00 AND 350.00
ORDER BY unit_price DESC;

-- Query B: Storage and Audio items that are running low (under 25 in stock)
SELECT sku, product_name, category, stock_qty
FROM products
WHERE category IN ('Storage', 'Audio')
  AND stock_qty < 25
ORDER BY stock_qty ASC;

-- Query C: Any product whose name contains the word "SSD"
-- % means "any characters", so '%SSD%' matches "SSD" anywhere in the name
SELECT sku, product_name, unit_price
FROM products
WHERE product_name LIKE '%SSD%'
ORDER BY product_name ASC;

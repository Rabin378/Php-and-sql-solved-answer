<?php
// ===== Starter data (given) =====
$statusCodes = [200, 201, 301, 400, 404, 500, '200', 999];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> HTTP status Dispatcher </h1>
<table border = "1">
    <tr>
        <th> Status Code </th>
        <th> Data type </th>
        <th> Description </th>
</tr>
<?php foreach ($statusCodes as $code): ?>

<?php 
$description = match ($code) {
    200, 201 => 'Success: Request Completed',
    301, 302 => 'Redirect: Resource moved',
    400, 401, 403 => 'Client Error: Bad request or unauthorized',
    404 => 'Client Error: Not Found',
    500, 503 => 'Server Error: Internal Failure',
    default => 'Unknown or non-integer status code',
};
?>

<tr>
    <td><?= htmlspecialchars((string)$code, ENT_QUOTES, 'UTF-8')?></td>
    <td><?= htmlspecialchars(gettype($code), ENT_QUOTES, 'UTF-8')?></td>
    <td><?= htmlspecialchars($description, ENT_QUOTES, 'UTF-8') ?></td>
</tr>

<?php endforeach; ?>
</table>
</body>
</html>
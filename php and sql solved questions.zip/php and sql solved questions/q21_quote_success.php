<?php
// Read the query string parameters from the URL
$company = $_GET['company'] ?? 'Unknown Company';
$items   = $_GET['items'] ?? 'None';
$qty     = $_GET['qty'] ?? '0';
$total   = $_GET['total'] ?? '0.00';
?>
<!DOCTYPE html>
<html>
<head><title>Quote Confirmed</title></head>
<body>
    <h2>Quote Confirmed!</h2>
    <p>Thank you, <strong><?= htmlspecialchars($company, ENT_QUOTES, 'UTF-8') ?></strong>.</p>
    <p>We have generated your quote for:</p>
    
    <ul>
        <li><strong>Items:</strong> <?= htmlspecialchars($items, ENT_QUOTES, 'UTF-8') ?></li>
        <li><strong>Quantity per item:</strong> <?= htmlspecialchars((string)$qty, ENT_QUOTES, 'UTF-8') ?></li>
    </ul>

    <h3>Final Total: $<?= htmlspecialchars($total, ENT_QUOTES, 'UTF-8') ?></h3>
    
    <a href="q21_quote_builder.php">Build Another Quote</a>
</body>
</html>
<?php
declare(strict_types=1);
require_once __DIR__ . '/q22_functions.php';

// 1. The Dataset
$products = [
    ['sku' => 'HW-101', 'product_name' => 'Mechanical Keyboard RGB', 'category' => 'Peripherals', 'unit_price' => 89.99, 'stock_qty' => 24],
    ['sku' => 'HW-102', 'product_name' => 'Wireless Ergonomic Mouse', 'category' => 'Peripherals', 'unit_price' => 45.50, 'stock_qty' => 50],
    ['sku' => 'HW-103', 'product_name' => '27-inch 4K IPS Monitor', 'category' => 'Monitors', 'unit_price' => 329.00, 'stock_qty' => 12],
    ['sku' => 'HW-104', 'product_name' => 'USB-C 8-in-1 Hub', 'category' => 'Accessories', 'unit_price' => 34.95, 'stock_qty' => 85],
    ['sku' => 'HW-105', 'product_name' => '1TB NVMe M.2 SSD', 'category' => 'Storage', 'unit_price' => 79.99, 'stock_qty' => 30],
    ['sku' => 'HW-108', 'product_name' => 'Noise-Canceling USB Headset', 'category' => 'Audio', 'unit_price' => 64.00, 'stock_qty' => 40],
    ['sku' => 'HW-110', 'product_name' => 'Studio Condenser Microphone', 'category' => 'Audio', 'unit_price' => 115.00, 'stock_qty' => 9]
];

// --- POST HANDLING (Quick Reserve) ---
$post_errors = [];
$sticky_email = '';
$sticky_sku = '';
$sticky_qty = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sticky_email = trim($_POST['buyer_email'] ?? '');
    $sticky_sku = $_POST['sku'] ?? '';
    $sticky_qty = $_POST['qty'] ?? '';

    // Validate Email
    if (!filter_var($sticky_email, FILTER_VALIDATE_EMAIL)) {
        $post_errors[] = "Invalid email format.";
    }

    // Validate SKU (must exist in the dataset)
    $allowed_skus = array_column($products, 'sku');
    if (!in_array($sticky_sku, $allowed_skus, true)) {
        $post_errors[] = "Invalid product selected.";
    }

    // Validate Qty (1 to 10)
    $valid_qty = filter_var($sticky_qty, FILTER_VALIDATE_INT, [
        'options' => ['min_range' => 1, 'max_range' => 10]
    ]);
    if ($valid_qty === false) {
        $post_errors[] = "Quantity must be a whole number between 1 and 10.";
    }

    // If success, REDIRECT!
    if (empty($post_errors)) {
        $query = http_build_query([
            'email' => $sticky_email,
            'sku' => $sticky_sku,
            'qty' => $valid_qty
        ]);
        header('Location: q22_order_confirmed.php?' . $query);
        exit;
    }
}

// --- GET HANDLING (Filters) ---
$allowedCategories = ['ALL', 'Peripherals', 'Monitors', 'Accessories', 'Storage', 'Audio'];
$filterCategory = $_GET['category'] ?? 'ALL';
if (!in_array($filterCategory, $allowedCategories, true)) {
    $filterCategory = 'ALL';
}

$filterMaxPrice = $_GET['max_price'] ?? '500.00';
$validMaxPrice = filter_var($filterMaxPrice, FILTER_VALIDATE_FLOAT);
// Ensure it's between 10 and 1000
if ($validMaxPrice === false || $validMaxPrice < 10.00 || $validMaxPrice > 1000.00) {
    $validMaxPrice = 500.00;
}

// Filter the products array
$filteredProducts = [];
foreach ($products as $p) {
    $catMatch = ($filterCategory === 'ALL' || $p['category'] === $filterCategory);
    $priceMatch = ($p['unit_price'] <= $validMaxPrice);
    
    if ($catMatch && $priceMatch) {
        $filteredProducts[] = $p;
    }
}

// Get Stats using our function
$stats = calculateCatalogStats($filteredProducts);
?>
<!DOCTYPE html>
<html>
<head><title>Storefront Explorer</title></head>
<body>
    <h2>Storefront Explorer</h2>

    <!-- GET Filter Form -->
    <form method="GET">
        <label>Category:</label>
        <select name="category">
            <?php foreach ($allowedCategories as $cat): ?>
                <option value="<?= $cat ?>" <?= $filterCategory === $cat ? 'selected' : '' ?>>
                    <?= $cat ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <label>Max Price:</label>
        <input type="number" step="0.01" name="max_price" value="<?= htmlspecialchars((string)$validMaxPrice, ENT_QUOTES, 'UTF-8') ?>">
        
        <button type="submit">Filter</button>
    </form>

    <!-- Metrics Banner -->
    <div style="background:#eee; padding:10px; margin:10px 0;">
        <strong>Matches:</strong> <?= $stats['count'] ?> | 
        <strong>Avg Price:</strong> $<?= number_format($stats['avg'], 2) ?> | 
        <strong>Min:</strong> $<?= number_format($stats['min'], 2) ?> | 
        <strong>Max:</strong> $<?= number_format($stats['max'], 2) ?>
    </div>

    <!-- Product Table -->
    <table border="1" cellpadding="5">
        <tr>
            <th>SKU</th><th>Name</th><th>Category</th><th>Price</th><th>Stock Status</th>
        </tr>
        <?php foreach ($filteredProducts as $p): ?>
            <tr>
                <td><?= htmlspecialchars($p['sku'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($p['product_name'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($p['category'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>$<?= number_format($p['unit_price'], 2) ?></td>
                <td><?= getStockBadge($p['stock_qty']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <hr>

    <!-- POST Quick Reserve Form -->
    <h3>Quick Reserve</h3>
    <?php if (!empty($post_errors)): ?>
        <ul style="color:red;">
            <?php foreach ($post_errors as $err): ?><li><?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></li><?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form method="POST">
        <label>Email:</label>
        <input type="text" name="buyer_email" value="<?= htmlspecialchars($sticky_email, ENT_QUOTES, 'UTF-8') ?>"><br><br>

        <label>Product SKU:</label>
        <select name="sku">
            <option value="">-- Select SKU --</option>
            <?php foreach ($products as $p): ?>
                <option value="<?= $p['sku'] ?>" <?= $sticky_sku === $p['sku'] ? 'selected' : '' ?>>
                    <?= $p['sku'] ?> - <?= htmlspecialchars($p['product_name'], ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Quantity (1-10):</label>
        <input type="number" name="qty" value="<?= htmlspecialchars($sticky_qty, ENT_QUOTES, 'UTF-8') ?>"><br><br>

        <button type="submit">Reserve</button>
    </form>
</body>
</html>
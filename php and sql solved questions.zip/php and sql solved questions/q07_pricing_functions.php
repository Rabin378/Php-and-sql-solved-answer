<?php

function calculateNetPrice(
    float $basePrice,
    float $discountPercent = 0.0,
    float $taxPercent = 10.0
): float  {
    $discountedPrice = $basePrice -($basePrice * ($discountPercent / 100));
    $netPrice = $discountedPrice + ($discountedPrice *($taxPercent / 100));

    return $netPrice;

}

function formatCurrency(
    float $amount,
    string $symbol= '$'):string {
        return $symbol.number_format($amount, 2);
    }

//Call 1;
$price1 = calculateNetPrice(100.00);

//call 2;
$price2 = calculateNetPrice(100.00, 20.0);

//call 3;
$price3 = calculateNetPrice(100.00, 20.0, 5.0);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Custom Pricing function </h1>
    <?php
    echo "<h2>Pricing Results</h2>";

    echo "<p>Call 1(0% discount, 10% tax): "
      .formatCurrency($price1). "</p>";

    echo "<p>Call 2(20% discount, 10% tax): "
       .formatCurrency($price2)."</p>";
    echo "<p>Call 3 (20% discount, 5% tax): "
       .formatCurrency($price3). "</p>";
?>
</body>
</html>


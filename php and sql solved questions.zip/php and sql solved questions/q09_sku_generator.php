<?php
// ===== Starter data (given) =====
$rawItems = [
    ['name' => '  ergonomic mouse ', 'category' => 'Peripherals'],
    ['name' => '4k gaming monitor',  'category' => 'Monitors'],
    ['name' => 'usb-c hub adapter',  'category' => 'Accessories'],
    ['name' => 'nvme ssd 1tb',       'category' => 'Storage']
];

function generateNextSku(string $category, string $prefix = 'WH'): 
string {
    static $sequence = 0;
    $sequence++;

    $trimmedCategory = trim($category);
    $cleanCategory = strtoupper($trimmedCategory);
    $categoryCode = substr($cleanCategory, 0, 3);

    $paddedSequence = str_pad(
        (string) $sequence,
        3,
        '0',
        STR_PAD_LEFT
    );
 $sku = implode('-',[$prefix, $categoryCode, $paddedSequence]);
 return $sku;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Inventory SKU Generator </h1>
    <ul>
        <?php
        foreach ($rawItems as $item) {
            $cleanName = ucwords(trim($item['name']));
            $sku = generateNextSku($item['category']);
        
        echo "<li>";
        echo htmlspecialchars($cleanName, ENT_QUOTES, 'UTF-8');
        echo "-";
        echo htmlspecialchars($sku, ENT_QUOTES, 'UTF-8');
        echo "</li>";
        }
?>
</ul>
</body>
</html>
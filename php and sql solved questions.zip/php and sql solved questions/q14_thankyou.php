
<?php
// Read username from the URL
$username = $_GET['user'] ?? 'Guest';

// Make sure the value is a string
if (!is_string($username)) {
    $username = 'Guest';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Thank You</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 650px;
            margin: 60px auto;
            padding: 20px;
            text-align: center;
        }

        .card {
            background: #f3fff3;
            border: 1px solid #80b880;
            padding: 30px;
            border-radius: 10px;
        }

        a {
            display: inline-block;
            margin-top: 15px;
        }
    </style>
</head>

<body>

    <div class="card">
        <h1>Thank You!</h1>

        <p>
            Thank you,
            <strong><?php
                echo htmlspecialchars(
                    $username,
                    ENT_QUOTES,
                    'UTF-8'
                );
            ?></strong>!
        </p>

        <p>Your support ticket has been submitted successfully.</p>

        <a href="q14_guestbook_preview.php">Return to the form</a>
    </div>

</body>
</html>


<?php
// Step 1: Create default variables
$studentName = '';
$comment = '';
$errors = [];
$isSubmitted = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $isSubmitted = true;

    $studentName = trim($_POST['student_name'] ?? '');
    $comment = trim($_POST['comment'] ?? '');

    $nameLength = strlen($studentName);

    if ($nameLength < 2 || $nameLength > 50) {
        $errors[] = 'Student name must be between 2 and 50 characters.';
    }

    $commentLength = strlen($comment);

    if ($commentLength < 10 || $commentLength > 300) {
        $errors[] = 'Feedback comment must be between 10 and 300 characters.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Question 11 - Course Feedback</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 650px;
            margin: 40px auto;
            padding: 20px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 5px;
        }

        button {
            margin-top: 15px;
            padding: 10px 18px;
            cursor: pointer;
        }

        .error {
            color: #b00020;
            background: #fff0f0;
            padding: 12px 30px;
            margin-bottom: 20px;
        }

        .success {
            border: 1px solid #80b880;
            padding: 20px;
            border-radius: 8px;
            background: #f3fff3;
        }
    </style>
</head>

<body>

    <h1>Course Feedback Form</h1>

    <!-- Step 6: Display validation errors -->
    <?php if (!empty($errors)): ?>
        <div class="error">
            <h2>Please correct these errors:</h2>

            <ul>
                <?php foreach ($errors as $error): ?>
                    <li>
                        <?php
                        echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8');
                        ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>


    <!-- Step 7: Show confirmation if valid; otherwise show the form -->
    <?php if ($isSubmitted && empty($errors)): ?>

        <div class="success">
            <h2>Feedback Submitted Successfully!</h2>

            <p>
                Thank you,
                <strong>
                    <?php
                    echo htmlspecialchars(
                        $studentName,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>
                </strong>.
            </p>

            <p>Your feedback:</p>

            <p>
                <?php
                echo nl2br(
                    htmlspecialchars(
                        $comment,
                        ENT_QUOTES,
                        'UTF-8'
                    )
                );
                ?>
            </p>
        </div>

    <?php else: ?>

        <!-- Step 8: Display the form -->
        <form method="post" action="">

            <label for="student_name">Student Name</label>

            <input
                type="text"
                id="student_name"
                name="student_name"
                value="<?php
                    echo htmlspecialchars(
                        $studentName,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                ?>"
            >

            <label for="comment">Feedback Comment</label>

            <textarea
                id="comment"
                name="comment"
                rows="5"
            ><?php
                echo htmlspecialchars(
                    $comment,
                    ENT_QUOTES,
                    'UTF-8'
                );
            ?></textarea>

            <button type="submit">Submit Feedback</button>

        </form>

    <?php endif; ?>

</body>
</html>

USE webprog2_midterm;

-- Query 1: Specific hardware SKUs
SELECT product_id, sku, product_name, unit_price, stock_qty 
FROM products 
WHERE sku IN ('HW-101', 'HW-103', 'HW-107') 
ORDER BY product_name ASC;

-- Query 2: Low Stock Alert
SELECT sku, product_name, stock_qty 
FROM products 
WHERE stock_qty < 15 
ORDER BY stock_qty ASC;
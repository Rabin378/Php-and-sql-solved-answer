
<?php
$customerName = "Alex Rivera";
$itemTitle    = "Mechanical Keyboard";
$unitPrice    = 89.99;
$quantity     = 3;
$taxRate      = 0.08;
$promoInput   = "100";
$targetPromo  = 100;

// Calculate invoice amounts
$subtotal   = $unitPrice * $quantity;
$taxAmount  = $subtotal * $taxRate;
$grandTotal = $subtotal + $taxAmount;

// Create receipt header
$receiptHeader = "Customer: " . $customerName . " | Item: " . $itemTitle;

// Compare promo codes
$looseMatch  = $promoInput == $targetPromo;
$strictMatch = $promoInput === $targetPromo;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question 1 - Order Invoice Calculator</title>
</head>
<body>

    <h1>Order Invoice Calculator</h1>

    <?php
    echo "<h2>Receipt</h2>";
    echo "<p>" . $receiptHeader . "</p>";

    echo "<p>Unit Price: $" . number_format($unitPrice, 2) . "</p>";
    echo "<p>Quantity: " . $quantity . "</p>";
    echo "<p>Subtotal: $" . number_format($subtotal, 2) . "</p>";
    echo "<p>Tax (8%): $" . number_format($taxAmount, 2) . "</p>";
    echo "<p>Grand Total: $" . number_format($grandTotal, 2) . "</p>";

    echo "<h2>Data Types</h2>";
    echo "<p>Customer Name: " . gettype($customerName) . "</p>";
    echo "<p>Item Title: " . gettype($itemTitle) . "</p>";
    echo "<p>Unit Price: " . gettype($unitPrice) . "</p>";
    echo "<p>Quantity: " . gettype($quantity) . "</p>";
    echo "<p>Promo Input: " . gettype($promoInput) . "</p>";
    echo "<p>Target Promo: " . gettype($targetPromo) . "</p>";

    echo "<h2>Promo Code Comparison</h2>";
    echo "<p>Loose Match (==): "
        . var_export($looseMatch, true) . "</p>";

    echo "<p>Strict Match (===): "
        . var_export($strictMatch, true) . "</p>";
    ?>

</body>
</html>

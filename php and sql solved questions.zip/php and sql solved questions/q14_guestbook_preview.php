<?php
// ===== Sticky values =====
$username    = '';
$message     = '';
$action      = '';
$errors      = [];
$showPreview = false;


if ($_SERVER['REQUEST_METHOD']=== 'POST') {
    $username  = trim($_POST['username'] ?? ''); //trim
    $message = trim($_POST['message'] ?? '');
    $action = trim($_POST['action'] ?? '');

    //validate username length
    if(strlen($username) < 3|| strlen($username) > 30) {
        $errors[] = 'Username must be between 3 and 30 characters.';
    }

    //validate message length 
    if(strlen($message) < 5 || strlen($message) > 500) {
        $errors[] = 'Message must be between 5 and 500 characters.';

    }
    //validate the required action
    if(!in_array($action,['preview', 'submit'], true)) {
        $errors[] = 'Please choose preview or submit final.';
    }

    if(empty($errors) && $action === 'submit' ) {
        header(
            'Location: q14_thankyou.php?user=' . urlencode($username)
        );
        exit;
    }

    if(empty($errors) && $action === 'preview') {
        $showPreview  = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guestbook preview</title>
<head>
     <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 650px;
            margin: 40px auto;
            padding: 20px;
            line-height: 1.6;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 5px;
        }

        button {
            margin-top: 15px;
            margin-right: 8px;
            padding: 10px 18px;
            cursor: pointer;
        }

        .error {
            color: #b00020;
            background: #fff0f0;
            padding: 12px 30px;
            margin-bottom: 20px;
        }

        .preview {
            background: #f1f6ff;
            border: 1px solid #8aaee8;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
            overflow-wrap: anywhere;
        }

        .message {
            white-space: pre-wrap;
        }
    </style>

</head>
<body>
    <h1> Support ticket form </h1>

<?php if(!empty($errors)) : ?>
    <div class = "error">

    <h2>Please correct these errors</h2>
    <ul> <?php foreach ($errors as $error): ?>
        <li>
            <?php
            echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8');?>
            <?php endforeach; ?>
            </ul>
            </div>
            <?php endif; ?>

    <form  method = "post" action = "">

    <label for="username">Username (3 - 30 characters) </label>

    <input
    type = "text"
    id = "username"
    name = "username"
    value = "<?php
    echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>" 
     required >


<label for = "message">Message (5- 200 characters) </label>

<textarea
id = "message"
name = "message"
rows = "5"
required ><?php
 echo htmlspecialchars($message,  ENT_QUOTES, 'UTF-8'); ?></textarea>


<button type = "submit" name = "action" value = "preview">
    Preview
            </button>

    <button type = "submit"  name = "action" value = "submit">
        Submit final
            </button>


<?php if($showPreview): ?>

    <div class = "preview">
        <h2>Manager Preview</h2>
        <p>
            <strong>Username:</strong> <?php
            echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?> </div>
            </div>

        <?php endif; ?>

</body>
</html>



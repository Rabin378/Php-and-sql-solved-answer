<?php
declare(strict_types=1);

// 1. Stock Badge
function getStockBadge(int $qty): string {
    return match (true) {
        $qty <= 0  => 'Out of Stock',
        $qty < 15  => 'Low Stock',
        default    => 'In Stock'
    };
}

// 2. Catalog Stats
function calculateCatalogStats(array $items): array {
    // Safety check: if the array is empty, return zeros to avoid PHP errors
    if (count($items) === 0) {
        return ['count' => 0, 'avg' => 0.0, 'min' => 0.0, 'max' => 0.0];
    }

    $count = count($items);
    $total = 0;
    $min = $items[0]['unit_price']; // Set first item as initial min
    $max = $items[0]['unit_price']; // Set first item as initial max

    foreach ($items as $item) {
        $price = $item['unit_price'];
        $total += $price;
        
        if ($price < $min) $min = $price;
        if ($price > $max) $max = $price;
    }

    return [
        'count' => $count,
        'avg'   => $total / $count,
        'min'   => $min,
        'max'   => $max
    ];
}
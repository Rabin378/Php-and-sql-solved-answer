<?php

$scores = [
    'Kim Min-jun'   => 92,
    'Park Seo-yeon' => 64,
    'Lee Ji-hoon'   => 78,
    'Choi Su-bin'   => 85,
    'Jung Woo-jin'  => 59,
    'Han Ji-min'    => 95
];

$totalScore = 0;
$passCount = 0;
$totalStudents = count($scores);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Gradebook</title>
</head>
<body>

<h1>Student Gradebook</h1>

<table border="1">
    <tr>
        <th>Student Name</th>
        <th>Score</th>
        <th>Status</th>
    </tr>

    <?php foreach ($scores as $student => $score): ?>

        <?php
        $totalScore += $score;

        if ($score >= 70) {
            $passCount++;
            $status = "Pass";
        } else {
            $status = "Retake";
        }
        ?>

        <tr>
            <td><?= htmlspecialchars($student, ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= $score ?></td>
            <td><?= $status ?></td>
        </tr>

    <?php endforeach; ?>
</table>

<?php
$classAverage = $totalScore / $totalStudents;
?>

<p>Total Students: <?= $totalStudents ?></p>
<p>Passed: <?= $passCount ?></p>
<p>Class Average: <?= number_format($classAverage, 1) ?></p>

</body>
</html>
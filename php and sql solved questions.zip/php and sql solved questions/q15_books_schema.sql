-- Q15: Table design for the campus bookstore
-- Run this whole file in phpMyAdmin (SQL tab) and click Go.

USE webprog2_midterm;

DROP TABLE IF EXISTS books;   -- lets you re-run the file safely

CREATE TABLE books (
    book_id        INT AUTO_INCREMENT PRIMARY KEY,  -- whole number, counts up by itself
    isbn           VARCHAR(17)  NOT NULL,           -- text up to 17 characters
    title          VARCHAR(120) NOT NULL,           -- text up to 120 characters
    retail_price   DECIMAL(6,2) NOT NULL,           -- exact money: up to 6 digits, 2 after the dot
    published_date DATE         NOT NULL,           -- YYYY-MM-DD
    in_print       TINYINT(1)   NOT NULL DEFAULT 1  -- 1 = yes, 0 = no
);

-- Test row: notice we do NOT give book_id or in_print; they fill in automatically
INSERT INTO books (isbn, title, retail_price, published_date)
VALUES ('978-0-13-110362-7', 'The C Programming Language', 59.99, '1988-04-01');

-- Check the structure (book_id should show PRI + auto_increment, in_print default 1)
SHOW COLUMNS FROM books;

-- Check the data
SELECT * FROM books;

<?php

$allowedThemes = ['light', 'dark', 'sepia'];
$allowedSizes = ['small', 'medium', 'large'];

$theme = $_GET['theme'] ??'light';
$size = $_GET['size'] ?? 'medium';

$warnings = [];

if (!in_array($theme, $allowedThemes, true)) {
    $theme = 'light';
    $warnings[] = 'Invalid theme. Default theme (light) has been selected.';
}
if (!in_array($size, $allowedSizes, true)) {
    $size = 'medium'; 
    $warnings[] = 'Invalid font size. Default size(medium) has been selected.';
    
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question 10 - Theme Switcher</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .light {
            background-color: white;
            color: black;
        }

        .dark {
            background-color: #222;
            color: white;
        }

        .sepia {
            background-color: #f4ecd8;
            color: #5b4636;
        }

        .small {
            font-size: 14px;
        }

        .medium {
            font-size: 18px;
        }

        .large {
            font-size: 24px;
        }

        .warning {
            color: red;
        }

        a {
            display: inline-block;
            margin: 5px;
        }
    </style>
</head>

<body class="<?php
    echo htmlspecialchars($theme, ENT_QUOTES, 'UTF-8');
?>">

    <h1>Documentation Reader</h1>

    <p>
        Active theme:
        <strong><?php echo htmlspecialchars($theme, ENT_QUOTES, 'UTF-8'); ?></strong>
    </p>

    <p>
        Active font size:
        <strong><?php echo htmlspecialchars($size, ENT_QUOTES, 'UTF-8'); ?></strong>
    </p>

    <div class="<?php
        echo htmlspecialchars($size, ENT_QUOTES, 'UTF-8');
    ?>">
        <p>This is sample documentation text.</p>
        <p>You can change the theme and font size using the links below.</p>
    </div>

    <h2>Choose a setting</h2>

    <a href="?theme=light&size=medium">Light + Medium</a>
    <a href="?theme=dark&size=large">Dark + Large</a>
    <a href="?theme=sepia&size=small">Sepia + Small</a>
    <a href="?theme=neon&size=giant">Test Invalid Values</a>

    <?php if (!empty($warnings)): ?>
        <h2 class="warning">Warnings</h2>

        <ul>
            <?php foreach ($warnings as $warning): ?>
                <li>
                    <?php
                    echo htmlspecialchars($warning, ENT_QUOTES, 'UTF-8');
                    ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</body>
</html>

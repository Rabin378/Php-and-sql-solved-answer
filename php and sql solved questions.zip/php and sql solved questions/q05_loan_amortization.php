<?php
// ===== Starter data (given) =====
$initialSavings = 500.00;
$monthlyDeposit = 150.00;

$loanBalance    = 1000.00;
$monthlyPayment = 300.00;

$attempt        = 1;
$maxAttempts    = 1;   // Even if already at max, do...while runs its body once
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Loops Showdown(for, while, do...while)</h1>
    <h2> saving projection: (for)</h2>
    <ul>
    <?php for ($month = 1 ; $month <= 6;  $month++): ?>
        <?php $initialSavings += $monthlyDeposit ; ?>
        <li>Month <?= $month ?>: <?= number_format($initialSavings, 2) ?></li>
    <?php endfor; ?>
    </ul>

<h2> Loan Payoff Simulator: (while)</h2>
<ul>
    <?php 
    $paymentNumber = 0;
    while  ($loanBalance> 0):
        $paymentNumber++;
    if ($loanBalance < $monthlyPayment) {
        $paymentAmount = $loanBalance;
        $loanBalance = 0;
    } else {
        $paymentAmount = $monthlyPayment;
        $loanBalance -= $monthlyPayment;
    } ?>
    <li> Payment #<?=$paymentNumber ?>:
    <?= number_format($paymentAmount, 2) ?>|
    Remaining Balance: <?= number_format($loanBalance , 2) ?></li>
    <?php endwhile; ?>
    </ul>
    <p>Paid off in <?= $paymentNumber ?> months. </p>

<h2> Diagnostic Ping (do... while) </h2>
<ul>
    <?php 
    do {
        $attemptValue = $attempt;
        $attempt++;
     ?>
     <li> Diagnostic Ping attempt #<?= $attemptValue ?></li>
     <?php  } while ($attempt <= $maxAttempts); ?>
    </ul>

</body>
</html>


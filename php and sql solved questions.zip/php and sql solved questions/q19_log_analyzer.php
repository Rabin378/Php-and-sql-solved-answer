<?php

declare(strict_types =1);

require_once __DIR__ . '/q19_functions.php';

// Sample log data.
// Keep the exact dataset supplied in your lab materials if different.
$logs = [
    [
        'method' => 'GET',
        'path' => '/index.php',
        'status' => 200,
        'ms' => 120,
    ],
    [
        'method' => 'POST',
        'path' => '/login.php',
        'status' => 401,
        'ms' => 600,
    ],
    [
        'method' => 'POST',
        'path' => '/checkout.php',
        'status' => 500,
        'ms' => 1000,
    ],
    [
        'method' => 'GET',
        'path' => '/products.php',
        'status' => 200,
        'ms' => 250,
    ],
];

// Escape all dynamic output placed in HTML.
function h(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

// Validate the HTTP method against an allowed list.
$allowedMethods = ['ALL', 'GET', 'POST'];
$method = $_GET['method'] ?? 'ALL';

if (!is_string($method) || !in_array($method, $allowedMethods, true)) {
    $method = 'ALL';
}

// Validate min_ms as an integer from 0 to 5000.
$rawMinMs = $_GET['min_ms'] ?? '0';
$minMs = filter_var(
    $rawMinMs,
    FILTER_VALIDATE_INT,
    [
        'options' => [
            'min_range' => 0,
            'max_range' => 5000,
        ],
    ]
);

if ($minMs === false) {
    $minMs = 0;
}

// Filter using named arguments.
$filteredLogs = filterLogs(
    logs: $logs,
    method: $method,
    minMs: $minMs
);

// Calculate the average response time.
$totalMs = 0;

foreach ($filteredLogs as $log) {
    $totalMs += $log['ms'];
}

$averageMs = count($filteredLogs) > 0
    ? $totalMs / count($filteredLogs)
    : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server Access Log Analyzer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 30px auto;
            padding: 0 16px;
        }

        label {
            margin-right: 8px;
        }

        select, input, button {
            padding: 7px;
            margin: 5px 10px 10px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 18px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background: #eee;
        }
    </style>
</head>
<body>

<h1>Server Access Log Analyzer</h1>

<form method="get" action="">
    <label for="method">HTTP Method:</label>
    <select name="method" id="method">
        <option value="ALL" <?= $method === 'ALL' ? 'selected' : '' ?>>ALL</option>
        <option value="GET" <?= $method === 'GET' ? 'selected' : '' ?>>GET</option>
        <option value="POST" <?= $method === 'POST' ? 'selected' : '' ?>>POST</option>
    </select>

    <label for="min_ms">Minimum response time (ms):</label>
    <input
        type="number"
        id="min_ms"
        name="min_ms"
        min="0"
        max="5000"
        value="<?= h($minMs) ?>"
        required
    >

    <button type="submit">Filter Logs</button>
</form>

<p>
    <strong>Matching Entries:</strong>
    <?= count($filteredLogs) ?>
    |
    <strong>Average Response Time:</strong>
    <?= number_format($averageMs, 1) ?> ms
</p>

<table>
    <thead>
        <tr>
            <th>Method</th>
            <th>Path</th>
            <th>Status</th>
            <th>Status Badge</th>
            <th>Response Time (ms)</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($filteredLogs) === 0): ?>
            <tr>
                <td colspan="5">No matching logs found.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($filteredLogs as $log): ?>
                <tr>
                    <td><?= h($log['method']) ?></td>
                    <td><?= h($log['path']) ?></td>
                    <td><?= h($log['status']) ?></td>
                    <td><?= h(getStatusBadge($log['status'])) ?></td>
                    <td><?= h($log['ms']) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>

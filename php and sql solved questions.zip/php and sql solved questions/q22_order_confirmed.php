<?php
$email = $_GET['email'] ?? 'Unknown';
$sku = $_GET['sku'] ?? 'Unknown';
$qty = $_GET['qty'] ?? '0';
?>
<!DOCTYPE html>
<html>
<head><title>Order Confirmed</title></head>
<body>
    <h2>Reservation Confirmed!</h2>
    <p>Thank you! We have reserved your item.</p>
    
    <ul>
        <li><strong>Email:</strong> <?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?></li>
        <li><strong>Product SKU:</strong> <?= htmlspecialchars($sku, ENT_QUOTES, 'UTF-8') ?></li>
        <li><strong>Quantity:</strong> <?= htmlspecialchars((string)$qty, ENT_QUOTES, 'UTF-8') ?></li>
    </ul>

    <a href="q22_store_explorer.php">Return to Store</a>
</body>
</html>
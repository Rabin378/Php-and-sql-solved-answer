<?php
$weightKg = 6.5;
$zoneCode = 'REGIONAL';

$totalShipping = 0.0;
$error = null;

if ($weightKg <= 0) {
    $baseCost = 0.0;
    $error = "Invalid package weight.";
}
else if ($weightKg <= 2.0) {
    $baseCost = 5.00;

}else if ($weightKg <= 10.0 ){
    $baseCost = 12.50;
} else {
    $baseCost = 25.00;
}

switch ($zoneCode){
    case 'LOCAL':
        $surcharge = 0.00;
    break;
    case 'REGIONAL':
        $surcharge = 4.50;
    break;
    case 'INTL':
        $surcharge = 18.00;
    break;
    default:
    $surcharge = 10.00;
    break;
}

$totalShipping = $baseCost + $surcharge ;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> Shipping Rate Decision Engine </h1>
<?php if ($error !== null): ?>

    <p><strong><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></strong></p>

<?php else: ?>

    <p>Weight: <?= htmlspecialchars((string)$weightKg, ENT_QUOTES, 'UTF-8') ?> kg</p>
    <p>Zone: <?= htmlspecialchars($zoneCode, ENT_QUOTES, 'UTF-8') ?></p>
    <p>Base Cost: <?= number_format($baseCost, 2) ?></p>
    <p>Zone Surcharge: <?= number_format($surcharge, 2) ?></p>
    <p><strong>Total Shipping: <?= number_format($totalShipping, 2) ?></strong></p>

<?php endif; ?>

</body>
</html>

<?php
// Step 1: Create default variables

$availableTracks = [
    'web' => 'Web Development',
    'ai' => 'AI & Machine Learning',
    'cybersecurity' => 'Cybersecurity',
    'cloud' => 'Cloud Computing'
];

$password = '';
$selectedTopics = [];
$agreedToTerms = false;
$errors = [];
$isSubmitted = false;


// Step 2: Check whether the form was submitted

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isSubmitted = true;

    $password = $_POST['password'] ?? '';

    // Make sure the password is a string
    if (!is_string($password)) {
        $password = '';
        $errors[] = 'Invalid password input.';
    }

    // Step 3: Validate password rules

    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long.';
    }

    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter.';
    }

    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must contain at least one digit.';
    }

    // Step 4: Read and validate workshop topics

    $topics = $_POST['topics'] ?? [];

    if (!is_array($topics)) {
        $errors[] = 'Invalid workshop selection.';
        $topics = [];
    }

    // Only accept unique keys from our allowed list
    foreach ($topics as $topic) {
        if (
            !is_string($topic) ||
            !in_array($topic, array_keys($availableTracks), true)
        ) {
            $errors[] = 'Invalid workshop track selected.';
            continue;
        }

        if (!in_array($topic, $selectedTopics, true)) {
            $selectedTopics[] = $topic;
        }
    }

    // Step 5: Require between 1 and 3 tracks

    if (count($selectedTopics) < 1 || count($selectedTopics) > 3) {
        $errors[] = 'Please select between 1 and 3 workshop tracks.';
    }

    // Step 6: Validate Terms of Service

    $agreedToTerms = isset($_POST['agree_terms']);

    if (!$agreedToTerms) {
        $errors[] = 'You must agree to the Terms of Service.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Question 13 - Workshop Registration</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 650px;
            margin: 40px auto;
            padding: 20px;
            line-height: 1.6;
        }

        label {
            display: block;
            margin-top: 12px;
        }

        input[type="password"] {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 5px;
        }

        .track,
        .terms {
            margin: 10px 0;
        }

        button {
            margin-top: 18px;
            padding: 10px 18px;
            cursor: pointer;
        }

        .error {
            color: #b00020;
            background: #fff0f0;
            padding: 12px 30px;
            margin-bottom: 20px;
        }

        .success {
            border: 1px solid #80b880;
            background: #f3fff3;
            padding: 20px;
            border-radius: 8px;
        }
    </style>
</head>

<body>

    <h1>Developer Workshop Registration</h1>

    <!-- Step 7: Display errors -->

    <?php if (!empty($errors)): ?>
        <div class="error">
            <h2>Please correct these errors:</h2>

            <ul>
                <?php foreach ($errors as $error): ?>
                    <li>
                        <?php
                        echo htmlspecialchars(
                            $error,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>


    <!-- Step 8: Show success or redisplay the form -->

    <?php if ($isSubmitted && empty($errors)): ?>

        <div class="success">
            <h2>Registration Successful!</h2>

            <p>Your workshop tracks:</p>

            <ul>
                <?php foreach ($selectedTopics as $topic): ?>
                    <li>
                        <?php
                        echo htmlspecialchars(
                            $availableTracks[$topic],
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <p>You have successfully registered for the workshop.</p>
        </div>

    <?php else: ?>

        <form method="post" action="">

            <!-- Password: deliberately NOT sticky -->

            <label for="password">
                <strong>Password</strong>
            </label>

            <input
                type="password"
                id="password"
                name="password"
                autocomplete="new-password"
                required
            >

            <p>
                Password must be at least 8 characters long,
                contain an uppercase letter and contain a digit.
            </p>


            <!-- Workshop tracks: sticky checkboxes -->

            <h3>Select Workshop Tracks (1–3)</h3>

            <?php foreach ($availableTracks as $key => $label): ?>

                <label class="track">
                    <input
                        type="checkbox"
                        name="topics[]"
                        value="<?php
                            echo htmlspecialchars(
                                $key,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                        <?php
                        if (in_array($key, $selectedTopics, true)) {
                            echo 'checked';
                        }
                        ?>
                    >

                    <?php
                    echo htmlspecialchars(
                        $label,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>
                </label>

            <?php endforeach; ?>


            <!-- Terms checkbox: sticky -->

            <h3>Terms of Service</h3>

            <label class="terms">
                <input
                    type="checkbox"
                    name="agree_terms"
                    value="yes"
                    <?php
                    if ($agreedToTerms) {
                        echo 'checked';
                    }
                    ?>
                >

                I agree to the Terms of Service.
            </label>

            <button type="submit">Register</button>

        </form>

    <?php endif; ?>

</body>
</html>
